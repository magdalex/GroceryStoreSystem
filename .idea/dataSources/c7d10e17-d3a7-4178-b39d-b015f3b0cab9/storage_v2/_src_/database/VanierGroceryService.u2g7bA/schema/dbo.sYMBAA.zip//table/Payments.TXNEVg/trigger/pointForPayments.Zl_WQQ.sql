CREATE trigger pointForPayments  on Payments  after insert as
update Accounts set pointBalance = cast((select try_parse(totalCost as numeric) from Orders join inserted on Orders.orderID = inserted.orderID)*0.02 + (
    select pointBalance from Accounts join inserted on emailAccount = accountID) as int) where Accounts.emailAccount = (select top 1 accountID from inserted);
go

